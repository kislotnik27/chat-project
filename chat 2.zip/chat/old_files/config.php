<?php
return [
    'telegram' => [
        'api_key' => '7344106694:AAE0msZAFgdLRcFPgQ_oUQYqvVonY53zdeY',
        'bot_username' => '@elaliza_chat_bot',
    ],
    'viber' => [
        'api_key' => 'YOUR_VIBER_BOT_API_KEY',
        'bot_name' => 'YOUR_VIBER_BOT_NAME',
    ],
    'db' => [
        'host' => 'fm451400.mysql.tools',
        'dbname' => 'fm451400_work',
        'username' => 'fm451400_work',
        'password' => 'Sania2707_',
    ],
];
