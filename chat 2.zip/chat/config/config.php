<?php
return [
    'telegram' => [
        'api_key' => '7344106694:AAE0msZAFgdLRcFPgQ_oUQYqvVonY53zdeY',
        'bot_username' => '@elaliza_chat_bot',
    ],
    'viber' => [
        'token' => '4e42d4899aa7e050-115fbb4dc0a95a14-b1181064d5c17aba',
        'bot_name' => 'elaliza_helper',
    ],
    'db' => [
        'host' => 'fm451400.mysql.tools',
        'dbname' => 'fm451400_work',
        'username' => 'fm451400_work',
        'password' => 'Sania2707_',
    ],
    'websocket' => [
        'url' => 'wss://ws.elaliza.com',
    ],
];
