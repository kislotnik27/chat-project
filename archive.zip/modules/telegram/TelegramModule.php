<?php
namespace Modules\Telegram;

use Longman\TelegramBot\Telegram;
use Longman\TelegramBot\Request;
use WebSocket\Client;
use PDO;
use PDOException;

class TelegramModule {
    private $telegram;
    private $pdo;
    private $client;

    public function __construct($config) {
        $this->telegram = new Telegram($config['telegram']['api_key'], $config['telegram']['bot_username']);
        $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['dbname'] . ';charset=utf8';
        $this->pdo = new PDO($dsn, $config['db']['username'], $config['db']['password']);
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->client = new Client($config['websocket']['url']);
    }

    public function handleRequest() {
        $this->telegram->handle();
    }

    public function sendMessage($chat_id, $message, $reply_to_message_id = null) {
        $data = [
            'chat_id' => $chat_id,
            'text' => $message,
        ];

        if ($reply_to_message_id) {
            $data['reply_to_message_id'] = $reply_to_message_id;
        }

        return Request::sendMessage($data);
    }

    public function sendWebSocketMessage($message) {
        $this->client->send(json_encode($message));
    }

    public function saveUserAndMessage($platform, $user_id, $username, $first_name, $text, $sender = 'client', $media_url = null, $message_type = 'text', $message_id = null, $reply_to_message_id = null) {
        try {
            // Сохранение информации о пользователе
            $stmt = $this->pdo->prepare("INSERT INTO users (chat_id, name, platform) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name), platform = VALUES(platform)");
            $stmt->execute([$user_id, $first_name, $platform]);

            // Сохранение сообщения
            $stmt = $this->pdo->prepare("INSERT INTO messages (platform, user_id, message, sender, message_type, media_url, message_id_tg, reply_to_message_id, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$platform, $user_id, $text, $sender, $message_type, $media_url, $message_id, $reply_to_message_id]);

            return $this->pdo->lastInsertId();
        } catch (PDOException $e) {
            file_put_contents(__DIR__ . '/db_error.log', $e->getMessage() . PHP_EOL, FILE_APPEND);
            return null;
        }
    }

    public function updateMessageWithTelegramId($db_message_id, $telegram_message_id) {
        try {
            $stmt = $this->pdo->prepare("UPDATE messages SET message_id_tg = ? WHERE id = ?");
            $stmt->execute([$telegram_message_id, $db_message_id]);
        } catch (PDOException $e) {
            file_put_contents(__DIR__ . '/db_error.log', $e->getMessage() . PHP_EOL, FILE_APPEND);
        }
    }

    public function getMessageById($message_id_tg) {
        try {
            $stmt = $this->pdo->prepare('
                SELECT m.message, u.name as user 
                FROM messages m 
                JOIN users u ON m.user_id = u.chat_id 
                WHERE m.message_id_tg = ?
            ');
            $stmt->execute([$message_id_tg]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            file_put_contents(__DIR__ . '/db_error.log', $e->getMessage() . PHP_EOL, FILE_APPEND);
            return null;
        }
    }

    public function getMessages($chat_id, $last_id = 0) {
        try {
            $stmt = $this->pdo->prepare('
                SELECT m.id, m.message, m.media_url, m.message_type, m.message_id_tg, m.reply_to_message_id, m.timestamp, m.sender, u.name as user 
                FROM messages m 
                JOIN users u ON m.user_id = u.chat_id 
                WHERE m.user_id = ? AND m.id > ? 
                ORDER BY m.timestamp ASC
            ');
            $stmt->execute([$chat_id, $last_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            file_put_contents(__DIR__ . '/db_error.log', $e->getMessage() . PHP_EOL, FILE_APPEND);
            return null;
        }
    }

    public function getChats() {
        try {
            $stmt = $this->pdo->prepare('
                SELECT u.chat_id, u.name, m.message as last_message, u.platform 
                FROM users u 
                LEFT JOIN messages m ON u.chat_id = m.user_id 
                WHERE m.timestamp = (SELECT MAX(timestamp) FROM messages WHERE user_id = u.chat_id)
            ');
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            file_put_contents(__DIR__ . '/db_error.log', $e->getMessage() . PHP_EOL, FILE_APPEND);
            return null;
        }
    }
}
?>
