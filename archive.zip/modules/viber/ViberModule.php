<?php
namespace Modules\Viber;

use Viber\Bot;
use Viber\Api\Message\Text;
use PDO;
use PDOException;

class ViberModule {
    private $bot;
    private $pdo;

    public function __construct($config) {
        if (!isset($config['viber']['token'])) {
            throw new \RuntimeException('Viber API token is not specified in config');
        }
        
        $this->bot = new Bot(['token' => $config['viber']['token']]);

        $dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['dbname'] . ';charset=utf8';
        $this->pdo = new PDO($dsn, $config['db']['username'], $config['db']['password']);
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function setWebhook($url) {
        $this->bot->getClient()->setWebhook($url);
    }

    public function handleRequest() {
        $this->bot->onText('|.*|s', function ($event) {
            $message = $event->getMessage();
            $sender = $event->getSender();
            $text = $message->getText();
            $chat_id = $sender->getId();
            $user_name = $sender->getName();

            $this->saveUserAndMessage('viber', $chat_id, $sender->getName(), $sender->getName(), $text, 'client');

            // Отправка сообщения через WebSocket
            $this->sendWebSocketMessage([
                'event' => 'message',
                'user_id' => $chat_id,
                'user' => $user_name,
                'sender' => 'client',
                'message' => $text,
                'message_type' => 'text',
                'media_url' => null,
                'message_id_tg' => null,
                'reply_to_message_id' => null
            ]);

            return (new Text())->setText('Message received');
        });

        $this->bot->run();
    }

    public function saveUserAndMessage($platform, $user_id, $username, $first_name, $text, $sender = 'client', $media_url = null, $message_type = 'text', $message_id = null, $reply_to_message_id = null) {
        try {
            // Сохранение информации о пользователе
            $stmt = $this->pdo->prepare("INSERT INTO users (chat_id, name, platform) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name), platform = VALUES(platform)");
            $stmt->execute([$user_id, $first_name, $platform]);

            // Сохранение сообщения
            $stmt = $this->pdo->prepare("INSERT INTO messages (platform, user_id, message, sender, message_type, media_url, message_id_tg, reply_to_message_id, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$platform, $user_id, $text, $sender, $message_type, $media_url, $message_id, $reply_to_message_id]);
        } catch (PDOException $e) {
            file_put_contents(__DIR__ . '/db_error.log', $e->getMessage() . PHP_EOL, FILE_APPEND);
        }
    }

    public function sendWebSocketMessage($message) {
        // Реализация отправки сообщения через WebSocket
        try {
            $client = new \WebSocket\Client("wss://ws.elaliza.com");
            $client->send(json_encode($message));
        } catch (Exception $e) {
            file_put_contents(__DIR__ . '/websocket_error.log', "Failed to connect to WebSocket server: " . $e->getMessage() . PHP_EOL, FILE_APPEND);
        }
    }
}

?>
