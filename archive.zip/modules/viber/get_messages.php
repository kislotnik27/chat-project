<?php
header('Content-Type: application/json');

require '/home/fm451400/vendor/autoload.php';
require '/home/fm451400/elaliza.com/work/config/config.php';
require '/home/fm451400/elaliza.com/work/modules/viber/ViberModule.php';

use Modules\Viber\ViberModule;

$chat_id = $_GET['user_id'];
$last_id = isset($_GET['last_id']) ? $_GET['last_id'] : 0;

$viberModule = new ViberModule($config);

try {
    $messages = $viberModule->getMessages($chat_id, $last_id);
    echo json_encode(['status' => 'success', 'messages' => $messages]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
