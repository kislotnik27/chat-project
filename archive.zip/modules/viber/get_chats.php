<?php
header('Content-Type: application/json');

require '/home/fm451400/vendor/autoload.php';
require '/home/fm451400/elaliza.com/work/config/config.php';
require '/home/fm451400/elaliza.com/work/modules/viber/ViberModule.php';

use Modules\Viber\ViberModule;

$viberModule = new ViberModule($config);

try {
    $chats = $viberModule->getChats();
    echo json_encode(['status' => 'success', 'chats' => $chats]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
