<?php
header('Content-Type: application/json');

require '/home/fm451400/vendor/autoload.php';
require '/home/fm451400/elaliza.com/work/config/config.php';
require '/home/fm451400/elaliza.com/work/modules/viber/ViberModule.php';

use Modules\Viber\ViberModule;

$data = json_decode(file_get_contents('php://input'), true);
$user_id = $data['user_id'];
$message = $data['message'];

$viberModule = new ViberModule($config);

try {
    // Сохранение сообщения в базу данных
    $db_message_id = $viberModule->saveUserAndMessage('viber', $user_id, 'Manager', 'Manager', $message, 'manager', null, 'text', null, null);

    // Отправка сообщения через Viber API
    $viberModule->sendMessage($user_id, $message);

    echo json_encode(['status' => 'success']);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
